<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Signup </title>
  <link rel="stylesheet" type="text/css" href="style.css" media="all">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="../script/function.js" type="text/javascript"> </script>
</head>
<body>
<ul>
  <li><a class="active" href="index.php">Home </a></li> 
  <li><a href="nlogin.php">Login</a></li>
</ul>


<div class="contain">

	 	<fieldset>
	     <div class="header">
		    <h2>Plz your Product Add here!</h2>
		 </div>
		 
		 <form class="form-group" action="../model/proinsert.php" 
		 method="POST" enctype="multipart/form-data">
		 
		   
		 <div class="regi">
		     
		 
		     <div class="user">
			 <div>
			     <label>Product ID:</label>
				 <input type="text" name="pid"  required>
			 </div>
			 <div>
			     <label>Product Name:</label>
				 <input type="text"  name="panme"  required>
			 </div>
			 
			 <div>
			     <label>Product Price:</label>
				 <input type="text" name="pprice"  required>
			 </div>
			 
			 <div>
			     <label>Product Image:</label>
				 <p><input type="file" name="file_img" id="file_img" required></p>
			 </div>
			 
			 <div>
			     <label>Product Description:</label>
				 <textarea type="text" name="pdesc" rows="2" cols="30" required></textarea>
			 </div>
			
			 </div>
		</div>
			 
			 <div class="submit">
			     <button type="submit" name="btn_upload">Add new product</button>
							
			 </div>
			 
			 
			  
			
		 </form>
	</fieldset>

	 </div>
</body>
</html>

