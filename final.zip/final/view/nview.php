<p> <a href="../controller/nlogout.php">Logout</a></p>

<?php
include("../controller/nconfig.php");
include("../controller/nsession.php");
$sql="select * from cuinfor";
$results=mysqli_query($myconn,$sql);
echo'<table border="1px" width="100%"><tr> 
<th>Cu id</th> <th>name</th><th>Phone</th> <th>username</th>
<th>password</th><th>Edit</th><th>Delete</th></tr>';
while($row=mysqli_fetch_array($results))
{
    $cuid=$row['cuid'];
	$name=$row['name'];
	$phone=$row['phone'];
	$uname=$row['uname'];
	$pass=$row['password'];
echo '<tr>
    <th>'.$cuid.'</th><td>'.$name.'</td><td>'.$phone.'</td>
	<td>'.$uname.'</td><td>'.$pass.'</td>
	<td><a href="update.php?id='.$cuid.'">Edit</a></td>
	<td><a href="../model/delete.php?id='.$cuid.'">Delete</a></td>
	
</tr>';
}




?>