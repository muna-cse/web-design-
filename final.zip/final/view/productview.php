<!DOCTYPE html>
<html lang="en">
<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="style.css" media="all">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="../script/function.js" type="text/javascript"> </script>
</head>
<body>
<ul>
  <li><a href="index.php">Home </a></li> 
  <li><p> <a href="../controller/nlogout.php">Logout</a></p></li> 

</ul>

</body>
</html>


<?php
include("../controller/nconfig.php");
$sql="select * from product";
$result=mysqli_query($myconn,$sql);

while($row=mysqli_fetch_array($result))
{
	$name=$row['name'];
	$path=$row['img_path'];
	echo '<p>Product Name: '.$name.'</p><br>
	<img src="'.$path.'" style"=width:100px; height=100px;">';
	
	

}



?>