<head>
  <title>update </title>
  <link rel="stylesheet" type="text/css" href="style.css" media="all">
  <meta charset="utf-8"> 
</head>

<?php
include("../controller/nconfig.php");
$id=$_GET['id'];
$sql="select * from cuinfor where cuid='$id'";
$results=mysqli_query($myconn,$sql);

while($row=mysqli_fetch_array($results))
{
    $cuid=$row['cuid'];
	$name=$row['name'];
	$phone=$row['phone'];
	$uname=$row['uname'];
	$pass=$row['password'];
echo' 
<div class="contain">
<fieldset>
<form class="form-group" id="sform" onsubmit=" return formvali();" 
       action="" method="POST">
		 		   
		 <div class="regi">
		     		 
		     <div class="user">
			 <div>
			     <label>Name:</label>
				 <input type="text" name="name" value="'.$name.'"  required>
			 </div>
			 <div>
			     <label>Phone:</label>
				 <input type="number"  name="phone" value="'.$phone.'" required>
			 </div>
			 
			 <div>
			     <label>User Name:</label>
				 <input type="text" name="uname" value="'.$uname.'"  required>
			 </div>
			 
			 <div>
			     <label>Password:</label>
				 <input type="password" name="pass" value="'.$pass.'" required>
			 </div>
			 
			
			 </div>
		</div>
			 
			 <div class="submit">
			     <button type="submit" name="update">Update</button>
			 </div>
			 </form> 
</fieldset>	
</div>		 
';
}

?>
