<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Final Project</title>
    <link rel="stylesheet" type="text/css" href="style.css" media="all">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
 <div class="index">
<ul>
  <li><a class="active" href="index.php">Home </a></li> 
  <li><a href="nsignup.php">Signup</a></li>
  <li><a href="adproduct.php">Addproduct</a></li>
  <li><a href="productview.php">Allproduct</a></li>
  <li><a href="contact.php">Contact</a></li>
  <li><a href="nlogin.php">Login</a></li>
</ul>
</div>

<div class="row">
    <div  class="col-sm-12" style="background-color: green ; ">
    <p>Excel Sample Data
Below is a table with the Excel sample data used for many of my web site examples. You can use this sample data to create test files, and build Excel tables and pivot tables from the data. Copy and paste from this table, or download the sample data file.

Sample DataExcel Sample Data
Below is a table with the Excel sample data used for many of my web site examples. You can use this sample data to create test files, and build Excel tables and pivot tables from the data. Copy and paste from this table, or download the sample data file.

Sample Data

Sample Data Notes

Get the Sample Data

Create an Excel Table

Sample Data - Formatted Numbers

More Tutorials

Sample Data
Copy and paste the data from the table below. Or, to download the sample data in an Excel file, click this link: Excel sample data

Sample Data Notes

Get the Sample Data

Create an Excel Table

Sample Data - Formatted Numbers

More Tutorials

Sample Data
Copy and paste the data from the table below. Or, to download the sample data in an Excel file, click this link: Excel sample data
Excel Sample Data
Below is a table with the Excel sample data used for many of my web site examples. You can use this sample data to create test files, and build Excel tables and pivot tables from the data. Copy and paste from this table, or download the sample data file.

Sample Data

Sample Data Notes

Get the Sample Data

Create an Excel Table

Sample Data - Formatted Numbers

More Tutorials

Sample Data
Copy and paste the data from the table below. Or, to download the sample data in an Excel file, click this link: Excel sample data </p>
    </div>      
</div>
<div class="row">
    <div class="col-sm-12" style="background-color: black ; text-align:center; height:100px;">
	<p><h1>Footer</h1></p>
	</div>     
</div>




</body>
</html>
