<?php
//----------product save-----
if(isset($_POST['btn_upload']))
{
	$filetmp = $_FILES["file_img"]["tmp_name"];
	$filename = $_FILES["file_img"]["name"];
	$filetype = $_FILES["file_img"]["type"];
	$filepath = "../image/".$filename;
	
	move_uploaded_file($filetmp,$filepath);
}





//--------product insert------
include("../controller/nconfig.php");
        $id=$_POST['pid'];
        $name=$_POST['panme'];
        $price=$_POST['pprice'];
        $description=$_POST['pdesc'];

$sql="insert into product(proid,name,img_name,
      img_path,img_type,price,description)
	  
      value('$id','$name','$filename','$filepath',
      '$filetype','$price','$description')";
	  
$result=mysqli_query($myconn,$sql);
header("location:../view/productview.php");
	  
	  
	  
	  
	  
	  
?>