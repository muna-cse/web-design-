<?php
include("../controller/nconfig.php");

$name=$_POST['name'];
$phone=$_POST['phone'];
$uname=$_POST['uname'];
$pass=$_POST['pass'];
$sql="INSERT INTO cuinfor(name, phone, uname, password)
values('$name','$phone','$uname','$pass')";
$result=mysqli_query($myconn,$sql);

if($result===true)
	{
		header("location:../view/nview.php");
	}
else
	{
     	echo"Registration faild";
	}
?>