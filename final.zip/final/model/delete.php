<?php
include("../controller/nconfig.php");
$id=$_GET['id'];
$sql="delete from cuinfor where cuid='$id'";
$result=mysqli_query($myconn,$sql);
header("location:../view/nview.php");
?>