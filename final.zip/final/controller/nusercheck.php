<?php
session_start();
include("nconfig.php");
$username=$_POST['uname'];
$password=$_POST['pass'];

$sql = "select * from cuinfor where uname='$username' and password='$password'";
$result=mysqli_query($myconn,$sql);
$count=mysqli_num_rows($result);
if($count===1){
	
	$_SESSION['username']=$username;
	header("location:../view/productview.php ? username='.$username.'");
}
else
{
	echo'Password or user name wrong <a href="../view/nlogin.php">Try again</a>';
}



?>