<?php
include("../controller/nconfig.php");
$tbl_cuinfo="create table if not exists cuinfor(
cuid int(12) NOT NULL AUTO_INCREMENT,
primary key(cuid),
name varchar(45)  NOT NULL, 
phone varchar(45)  NOT NULL, 
uname varchar(45)  NOT NULL,
password varchar(45)  NOT NULL 
)";
$result=mysqli_query($myconn,$tbl_cuinfo);
if($result===TRUE)
{
	echo "Cuinfo tabel created ):";
}
else
{
		echo "Cuinfo tabel not created (:";

}

//----------product table--------
$tbl_product="create table if not exists product(
             proid int(12) not null,
             primary key(proid),
             name varchar(50) not null,
			 img_name varchar(50) not null,
			 img_path varchar(50) not null,
			 img_type varchar(50) not null,
			 price int(10) not null,
			 description varchar(400) not null
			 
)";
$result=mysqli_query($myconn,$tbl_product);
if($result===TRUE)
{
	echo "product tabel created ):";
}
else
{
		echo "product tabel not created (:";

}


?>